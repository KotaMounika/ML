
import streamlit as st
import pandas as pd
import joblib

st.title("Cryptocurrency Volatility Prediction App")

model = joblib.load("../models/volatility_model.pkl")

uploaded_file = st.file_uploader("Upload CSV file with feature columns", type=["csv"])

if uploaded_file:
    df = pd.read_csv(uploaded_file)
    predictions = model.predict(df)
    st.write("Predicted Volatility:")
    st.write(predictions)
